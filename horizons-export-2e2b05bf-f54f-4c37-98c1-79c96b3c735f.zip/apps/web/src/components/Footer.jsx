
import React from 'react';
import { Link } from 'react-router-dom';
import { Facebook, Instagram, MapPin, Phone, Mail } from 'lucide-react';

function Footer() {
  return (
    <footer className="bg-black text-white border-t border-white/10">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-16 max-w-7xl">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 lg:gap-8">
          <div className="lg:col-span-1">
            <span className="font-display text-2xl font-bold tracking-wider block mb-6">
              CRIMPENHOF
            </span>
            <p className="text-sm leading-relaxed text-white/70 mb-8 font-light">
              Luxe naaiatelier en stomerij. Vakmanschap en de hoogste zorg voor uw kleding en textiel.
            </p>
            <div className="flex gap-5">
              <a
                href="https://facebook.com"
                target="_blank"
                rel="noopener noreferrer"
                className="text-white/70 hover:text-white transition-colors duration-300"
                aria-label="Facebook"
              >
                <Facebook className="h-5 w-5" />
              </a>
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noopener noreferrer"
                className="text-white/70 hover:text-white transition-colors duration-300"
                aria-label="Instagram"
              >
                <Instagram className="h-5 w-5" />
              </a>
            </div>
          </div>

          <div>
            <h3 className="font-display text-lg mb-6 tracking-wide text-white">Menu</h3>
            <ul className="space-y-3">
              <li>
                <Link to="/" className="text-sm text-white/70 hover:text-white transition-colors duration-200">Home</Link>
              </li>
              <li>
                <Link to="/over-ons" className="text-sm text-white/70 hover:text-white transition-colors duration-200">Over ons</Link>
              </li>
              <li>
                <Link to="/diensten" className="text-sm text-white/70 hover:text-white transition-colors duration-200">Diensten</Link>
              </li>
              <li>
                <Link to="/zakelijke-diensten" className="text-sm text-white/70 hover:text-white transition-colors duration-200">Zakelijk</Link>
              </li>
              <li>
                <Link to="/prijzen" className="text-sm text-white/70 hover:text-white transition-colors duration-200">Prijzen</Link>
              </li>
              <li>
                <Link to="/contact" className="text-sm text-white/70 hover:text-white transition-colors duration-200">Contact</Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-display text-lg mb-6 tracking-wide text-white">Contact</h3>
            <ul className="space-y-4">
              <li className="flex items-start gap-3 text-sm text-white/70">
                <MapPin className="h-4 w-4 mt-0.5 text-white flex-shrink-0" />
                <span>Raad Huisplein 80B<br />2922 AD Krimpen aan den IJssel</span>
              </li>
              <li className="flex items-center gap-3 text-sm text-white/70">
                <Phone className="h-4 w-4 text-white flex-shrink-0" />
                <span>0180 554 425</span>
              </li>
              <li className="flex items-center gap-3 text-sm text-white/70">
                <Mail className="h-4 w-4 text-white flex-shrink-0" />
                <span>info@crimpenhof.nl</span>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-display text-lg mb-6 tracking-wide text-white">Openingstijden</h3>
            <ul className="space-y-2 text-sm text-white/70">
              <li className="flex justify-between border-b border-white/10 pb-2">
                <span>Maandag - Vrijdag</span>
                <span>09:00 - 17:30</span>
              </li>
              <li className="flex justify-between border-b border-white/10 pb-2 pt-2">
                <span>Zaterdag</span>
                <span>09:00 - 13:00</span>
              </li>
              <li className="flex justify-between pt-2">
                <span>Zondag</span>
                <span>Gesloten</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-16 pt-8 border-t border-white/10 flex flex-col md:flex-row justify-between items-center gap-4 text-xs text-white/50">
          <p>© {new Date().getFullYear()} Crimpenhof Naaiatelier & Stomerij. Alle rechten voorbehouden.</p>
          <div className="flex gap-6">
            <Link to="#" className="hover:text-white transition-colors">Privacybeleid</Link>
            <Link to="#" className="hover:text-white transition-colors">Algemene Voorwaarden</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}

export default Footer;
