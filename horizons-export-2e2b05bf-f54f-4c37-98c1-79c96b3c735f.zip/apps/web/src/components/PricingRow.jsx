
import React from 'react';

function PricingRow({ service, description, price }) {
  return (
    <div className="flex justify-between items-baseline py-3 border-b border-border/50 last:border-b-0 group">
      <div className="pr-4">
        <div className="font-medium text-foreground group-hover:text-muted-foreground transition-colors duration-200">{service}</div>
        {description && <div className="text-sm text-muted-foreground mt-0.5">{description}</div>}
      </div>
      <div className="font-display text-lg font-medium text-foreground whitespace-nowrap">{price}</div>
    </div>
  );
}

export default PricingRow;
