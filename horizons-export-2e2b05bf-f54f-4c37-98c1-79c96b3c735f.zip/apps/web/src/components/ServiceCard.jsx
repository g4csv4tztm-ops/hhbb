
import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { motion } from 'framer-motion';

function ServiceCard({ icon: Icon, title, description, className = '' }) {
  return (
    <Card className={`group relative overflow-hidden transition-all duration-300 hover:-translate-y-1 hover:shadow-xl border-border bg-card ${className}`}>
      <div className="absolute top-0 left-0 w-full h-1 bg-foreground transform origin-left scale-x-0 transition-transform duration-300 group-hover:scale-x-100" />
      <CardContent className="p-8">
        <div className="flex flex-col gap-6">
          <div className="flex-shrink-0 w-14 h-14 rounded-none border border-foreground/10 flex items-center justify-center bg-foreground/5 group-hover:bg-foreground/10 transition-colors duration-300">
            <Icon className="h-6 w-6 text-foreground" strokeWidth={1.5} />
          </div>
          <div>
            <h3 className="font-display text-xl font-medium mb-3 text-foreground tracking-wide">{title}</h3>
            <p className="text-sm text-muted-foreground leading-relaxed">{description}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export default ServiceCard;
