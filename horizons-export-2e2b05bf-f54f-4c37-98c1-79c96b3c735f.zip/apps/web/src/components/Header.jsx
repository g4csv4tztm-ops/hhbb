import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetTrigger, SheetTitle } from '@/components/ui/sheet';

function Header() {
  const [isOpen, setIsOpen] = useState(false);
  const location = useLocation();

  const navLinks = [
    { path: '/', label: 'Home' },
    { path: '/over-ons', label: 'Over ons' },
    { path: '/diensten', label: 'Diensten' },
    { path: '/zakelijke-diensten', label: 'Zakelijke diensten' },
    { path: '/prijzen', label: 'Prijzen' },
    { path: '/faq', label: 'FAQ' },
    { path: '/contact', label: 'Contact' },
  ];

  const isActive = (path) => location.pathname === path;

  return (
    <header className="sticky top-0 z-50 w-full border-b border-white/10 bg-black text-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-7xl">
        <div className="flex h-20 items-center justify-between">
          <Link to="/" className="flex items-center gap-2 transition-opacity duration-200 hover:opacity-80 z-10">
            <span className="font-display text-2xl font-bold tracking-wider">
              CRIMPENHOF
            </span>
          </Link>

          <nav className="hidden lg:flex items-center gap-6">
            {navLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                className={`text-sm tracking-wide uppercase transition-colors duration-200 ${
                  isActive(link.path)
                    ? 'text-white font-medium'
                    : 'text-white/70 hover:text-white'
                }`}
              >
                {link.label}
              </Link>
            ))}
          </nav>

          <div className="hidden lg:flex items-center gap-4">
            <Button asChild variant="outline" className="bg-transparent border-white text-white hover:bg-white/10 rounded-none tracking-widest uppercase text-xs px-6 transition-colors">
              <Link to="/zakelijke-diensten">Zakelijke diensten</Link>
            </Button>
            <Button asChild className="bg-white text-black hover:bg-white/90 rounded-none tracking-widest uppercase text-xs px-6 transition-colors">
              <Link to="/contact">Neem contact op</Link>
            </Button>
          </div>

          <Sheet open={isOpen} onOpenChange={setIsOpen}>
            <SheetTrigger asChild className="lg:hidden">
              <Button variant="ghost" size="icon" className="text-white hover:bg-white/10">
                <Menu className="h-6 w-6" />
                <span className="sr-only">Menu openen</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-full sm:w-[400px] bg-black border-l border-white/10 text-white pt-16">
              <SheetTitle className="sr-only">Navigatie Menu</SheetTitle>
              <div className="flex flex-col gap-6 mt-8">
                {navLinks.map((link) => (
                  <Link
                    key={link.path}
                    to={link.path}
                    onClick={() => setIsOpen(false)}
                    className={`text-lg tracking-widest uppercase transition-colors duration-200 ${
                      isActive(link.path)
                        ? 'text-white font-medium'
                        : 'text-white/70 hover:text-white'
                    }`}
                  >
                    {link.label}
                  </Link>
                ))}
                <div className="mt-8 pt-8 border-t border-white/10 space-y-3">
                  <Button asChild variant="outline" className="w-full bg-transparent border-white text-white hover:bg-white/10 rounded-none tracking-widest uppercase py-6">
                    <Link to="/zakelijke-diensten" onClick={() => setIsOpen(false)}>
                      Zakelijke diensten
                    </Link>
                  </Button>
                  <Button asChild className="w-full bg-white text-black hover:bg-white/90 rounded-none tracking-widest uppercase py-6">
                    <Link to="/contact" onClick={() => setIsOpen(false)}>
                      Neem contact op
                    </Link>
                  </Button>
                </div>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  );
}

export default Header;