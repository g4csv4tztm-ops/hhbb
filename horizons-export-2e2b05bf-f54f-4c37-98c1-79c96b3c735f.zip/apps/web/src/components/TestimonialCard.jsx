
import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Star } from 'lucide-react';

function TestimonialCard({ name, review, rating }) {
  return (
    <Card className="h-full border-border bg-card shadow-sm hover:shadow-md transition-shadow duration-300 break-inside-avoid mb-6">
      <CardContent className="p-8 flex flex-col h-full">
        <div className="flex gap-1 mb-6">
          {[...Array(5)].map((_, i) => (
            <Star
              key={i}
              className={`h-4 w-4 ${
                i < rating ? 'fill-foreground text-foreground' : 'text-muted-foreground/30'
              }`}
            />
          ))}
        </div>
        <blockquote className="text-base leading-loose mb-6 flex-1 font-display italic text-foreground/90">
          "{review}"
        </blockquote>
        <div className="mt-auto">
          <div className="h-px w-8 bg-foreground mb-4" />
          <p className="font-medium text-sm text-foreground tracking-wider uppercase">— {name}</p>
        </div>
      </CardContent>
    </Card>
  );
}

export default TestimonialCard;
