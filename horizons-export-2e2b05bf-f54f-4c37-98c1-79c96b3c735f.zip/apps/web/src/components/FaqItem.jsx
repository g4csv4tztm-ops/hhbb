
import React from 'react';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';

function FaqItem({ question, answer, value }) {
  return (
    <AccordionItem value={value} className="border-border">
      <AccordionTrigger className="text-left font-display text-lg hover:text-muted-foreground transition-colors duration-200">
        {question}
      </AccordionTrigger>
      <AccordionContent className="text-muted-foreground leading-relaxed text-base">
        {answer}
      </AccordionContent>
    </AccordionItem>
  );
}

export default FaqItem;
