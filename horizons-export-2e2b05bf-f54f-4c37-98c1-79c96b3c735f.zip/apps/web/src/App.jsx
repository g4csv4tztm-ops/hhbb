import React from 'react';
import { Route, Routes, BrowserRouter as Router } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import ScrollToTop from './components/ScrollToTop';
import HomePage from './pages/HomePage';
import OverOnsPage from './pages/OverOnsPage';
import DienstenPage from './pages/DienstenPage';
import ZakelijkeDienstenPage from './pages/ZakelijkeDienstenPage';
import PrijzenPage from './pages/PrijzenPage';
import ContactPage from './pages/ContactPage';
import FaqPage from './pages/FaqPage';
import { Toaster } from 'sonner';

function App() {
  return (
    <Router>
      <Helmet>
        <html lang="nl" />
        <title>Crimpenhof Naaiatelier & Stomerij | Krimpen aan den IJssel</title>
        <meta
          name="description"
          content="Luxe naaiatelier en stomerij in Krimpen aan den IJssel. Wij bieden kledingreparatie, maatkleding en professionele reiniging voor particulieren en bedrijven."
        />
        <meta
          name="keywords"
          content="naaiatelier Krimpen aan den IJssel, stomerij Krimpen aan den IJssel, kleding reparatie Krimpen aan den IJssel, kleding vermaken Krimpen aan den IJssel, zakelijke stomerij"
        />
        <script type="application/ld+json">
          {JSON.stringify({
            '@context': 'https://schema.org',
            '@type': 'LocalBusiness',
            name: 'Crimpenhof Naaiatelier & Stomerij',
            image: 'https://images.unsplash.com/photo-1445960169705-e0fb7b5c7f39',
            description: 'Luxe naaiatelier en stomerij in Krimpen aan den IJssel. Vakmanschap en zorg voor uw kleding.',
            address: {
              '@type': 'PostalAddress',
              streetAddress: 'Raad Huisplein 80B',
              addressLocality: 'Krimpen aan den IJssel',
              postalCode: '2922 AD',
              addressCountry: 'NL',
            },
            telephone: '0180554425',
            email: 'info@crimpenhof.nl',
            openingHoursSpecification: [
              {
                '@type': 'OpeningHoursSpecification',
                dayOfWeek: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'],
                opens: '09:00',
                closes: '17:30',
              },
              {
                '@type': 'OpeningHoursSpecification',
                dayOfWeek: 'Saturday',
                opens: '09:00',
                closes: '13:00',
              },
            ],
            priceRange: '€€',
          })}
        </script>
      </Helmet>
      
      <ScrollToTop />
      
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/over-ons" element={<OverOnsPage />} />
        <Route path="/diensten" element={<DienstenPage />} />
        <Route path="/zakelijke-diensten" element={<ZakelijkeDienstenPage />} />
        <Route path="/prijzen" element={<PrijzenPage />} />
        <Route path="/contact" element={<ContactPage />} />
        <Route path="/faq" element={<FaqPage />} />
        <Route path="*" element={
          <div className="min-h-screen flex items-center justify-center bg-black text-white text-center">
            <div>
              <h1 className="font-display text-4xl mb-4">Pagina niet gevonden</h1>
              <a href="/" className="text-accent underline uppercase tracking-widest text-sm">Terug naar home</a>
            </div>
          </div>
        } />
      </Routes>
      
      <Toaster position="bottom-right" richColors theme="light" />
    </Router>
  );
}

export default App;