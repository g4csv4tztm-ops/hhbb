
import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { MapPin, Phone, Mail, Clock } from 'lucide-react';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';

function ContactPage() {
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    message: '',
  });
  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  const validateForm = () => {
    const newErrors = {};

    if (!formData.name.trim()) newErrors.name = 'Naam is verplicht';
    if (!formData.email.trim()) {
      newErrors.email = 'E-mailadres is verplicht';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Ongeldig e-mailadres';
    }
    if (!formData.phone.trim()) newErrors.phone = 'Telefoonnummer is verplicht';
    if (!formData.message.trim()) newErrors.message = 'Bericht is verplicht';

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!validateForm()) return;

    setIsSubmitting(true);

    // Simulate API call and use localStorage
    setTimeout(() => {
      const submissions = JSON.parse(localStorage.getItem('contactSubmissions') || '[]');
      submissions.push({
        ...formData,
        timestamp: new Date().toISOString(),
      });
      localStorage.setItem('contactSubmissions', JSON.stringify(submissions));

      toast({
        title: 'Bericht succesvol verzonden',
        description: 'Wij nemen zo spoedig mogelijk contact met u op.',
      });

      setFormData({ name: '', email: '', phone: '', message: '' });
      setErrors({});
      setIsSubmitting(false);
    }, 1000);
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: '' }));
    }
  };

  return (
    <>
      <Helmet>
        <title>Contact | Crimpenhof Naaiatelier & Stomerij</title>
        <meta
          name="description"
          content="Neem contact op met Crimpenhof Naaiatelier & Stomerij in Krimpen aan den IJssel. Bel 0180 554 425 of bezoek onze winkel op Raad Huisplein 80B."
        />
      </Helmet>

      <Header />

      <main className="bg-background">
        <section className="py-24 bg-black text-white border-b border-white/10">
          <div className="container mx-auto px-4 max-w-4xl text-center">
            <h1 className="font-display text-4xl md:text-5xl font-medium mb-6">
              Neem <span className="text-white/80 italic">Contact</span> Op
            </h1>
            <p className="text-lg text-white/70 leading-relaxed font-light">
              Voor het plannen van een afspraak of een vrijblijvende prijsindicatie.
            </p>
          </div>
        </section>

        <section className="py-24">
          <div className="container mx-auto px-4 max-w-7xl">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
              
              {/* Contact Form */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6 }}
              >
                <h2 className="font-display text-2xl mb-8 border-b border-border pb-4">Stuur een bericht</h2>
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div>
                    <Label htmlFor="name" className="text-foreground uppercase tracking-wider text-xs">Naam</Label>
                    <Input
                      id="name"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      className="mt-2 rounded-none border-border focus-visible:ring-foreground text-foreground"
                      placeholder="Uw volledige naam"
                    />
                    {errors.name && <p className="text-sm text-destructive mt-1">{errors.name}</p>}
                  </div>

                  <div>
                    <Label htmlFor="email" className="text-foreground uppercase tracking-wider text-xs">E-mailadres</Label>
                    <Input
                      id="email"
                      name="email"
                      type="email"
                      value={formData.email}
                      onChange={handleChange}
                      className="mt-2 rounded-none border-border focus-visible:ring-foreground text-foreground"
                      placeholder="naam@voorbeeld.nl"
                    />
                    {errors.email && <p className="text-sm text-destructive mt-1">{errors.email}</p>}
                  </div>

                  <div>
                    <Label htmlFor="phone" className="text-foreground uppercase tracking-wider text-xs">Telefoonnummer</Label>
                    <Input
                      id="phone"
                      name="phone"
                      type="tel"
                      value={formData.phone}
                      onChange={handleChange}
                      className="mt-2 rounded-none border-border focus-visible:ring-foreground text-foreground"
                      placeholder="06 12345678"
                    />
                    {errors.phone && <p className="text-sm text-destructive mt-1">{errors.phone}</p>}
                  </div>

                  <div>
                    <Label htmlFor="message" className="text-foreground uppercase tracking-wider text-xs">Bericht</Label>
                    <Textarea
                      id="message"
                      name="message"
                      value={formData.message}
                      onChange={handleChange}
                      className="mt-2 min-h-[150px] rounded-none border-border focus-visible:ring-foreground text-foreground"
                      placeholder="Uw vraag of wens..."
                    />
                    {errors.message && <p className="text-sm text-destructive mt-1">{errors.message}</p>}
                  </div>

                  <Button
                    type="submit"
                    className="w-full bg-black text-white hover:bg-black/80 rounded-none uppercase tracking-widest py-6 transition-colors"
                    disabled={isSubmitting}
                  >
                    {isSubmitting ? 'Verzenden...' : 'Bericht Versturen'}
                  </Button>
                </form>
              </motion.div>

              {/* Contact Details & Map */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.2 }}
                className="space-y-12"
              >
                <div>
                  <h2 className="font-display text-2xl mb-8 border-b border-border pb-4">Onze Gegevens</h2>
                  <div className="space-y-6">
                    <div className="flex items-start gap-4">
                      <MapPin className="h-5 w-5 text-foreground mt-1" />
                      <div>
                        <p className="font-medium">Adres</p>
                        <p className="text-muted-foreground font-light mt-1">Raad Huisplein 80B<br/>2922 AD Krimpen aan den IJssel</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-4">
                      <Phone className="h-5 w-5 text-foreground mt-1" />
                      <div>
                        <p className="font-medium">Telefoon</p>
                        <p className="text-muted-foreground font-light mt-1">0180 554 425</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-4">
                      <Clock className="h-5 w-5 text-foreground mt-1" />
                      <div>
                        <p className="font-medium">Openingstijden</p>
                        <p className="text-muted-foreground font-light mt-1">Ma-Vr: 09:00 - 17:30<br/>Za: 09:00 - 13:00</p>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="h-[300px] w-full border border-border">
                  <iframe
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2460.627757913318!2d4.591040315802264!3d51.92244297970597!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47c433a0c5c3c0a5%3A0x6b772c9a9b8f2d!2sRaadhuisplein%2080B%2C%202922%20AD%20Krimpen%20aan%20den%20IJssel!5e0!3m2!1snl!2snl!4v1680000000000!5m2!1snl!2snl"
                    width="100%"
                    height="100%"
                    style={{ border: 0, filter: 'grayscale(100%) contrast(1.2)' }}
                    allowFullScreen=""
                    loading="lazy"
                    referrerPolicy="no-referrer-when-downgrade"
                    title="Locatie Crimpenhof"
                  ></iframe>
                </div>
              </motion.div>

            </div>
          </div>
        </section>
      </main>

      <Footer />
    </>
  );
}

export default ContactPage;
