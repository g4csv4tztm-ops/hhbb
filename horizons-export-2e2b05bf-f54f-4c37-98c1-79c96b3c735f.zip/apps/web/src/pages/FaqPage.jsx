
import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import FaqItem from '@/components/FaqItem.jsx';
import { Accordion } from '@/components/ui/accordion';

function FaqPage() {
  const faqs = [
    {
      question: 'Hoe lang duurt het voordat mijn kleding klaar is?',
      answer: 'De gemiddelde doorlooptijd voor stomerij is 3 tot 5 werkdagen. Voor kledingreparaties hangt het af van de complexiteit, maar reken doorgaans op 4 tot 7 werkdagen. Bij het afgeven van uw kleding bespreken we altijd een exacte ophaaldatum.',
    },
    {
      question: 'Doen jullie ook spoedopdrachten?',
      answer: 'Ja, afhankelijk van de drukte in het atelier kunnen wij spoedopdrachten aannemen. Hier kunnen wel extra kosten aan verbonden zijn. Neem hiervoor direct telefonisch contact met ons op via 0180 554 425.',
    },
    {
      question: 'Wat is inbegrepen bij "Speciaal stomen"?',
      answer: 'Bij speciaal stomen hanteren we zeer delicate reinigingsmethoden speciaal voor kwetsbare stoffen zoals zijde, kasjmier, of items met veel details zoals trouwjurken en galakleding. Elke vezel wordt zorgvuldig behandeld om beschadiging en kleurverlies te voorkomen.',
    },
    {
      question: 'Is het mogelijk om mijn broek "origineel" te laten inkorten?',
      answer: 'Absoluut. Wij kunnen jeans en andere pantalons origineel inkorten. Hierbij behouden we de originele wassing en de originele zoom van de broek, zodat de aanpassing nagenoeg onzichtbaar is. Dit is iets duurder (€16) dan normaal inkorten (€13).',
    },
    {
      question: 'Reinigen jullie ook lederen en suède kledingstukken?',
      answer: 'Ja, het reinigen van leder en suède vereist gespecialiseerde kennis, die wij in huis hebben. Wij stomen leren broeken en jassen met middelen die het leer voeden en beschermen.',
    },
    {
      question: 'Zijn jullie prijzen inclusief strijken?',
      answer: 'De prijzen voor stomerij zijn over het algemeen inclusief een basis persing. Voor losse kledingstukken die u puur wilt laten strijken berekenen we een toeslag van €4 tot €5 per stuk.',
    },
  ];

  return (
    <>
      <Helmet>
        <title>Veelgestelde Vragen | Crimpenhof Naaiatelier & Stomerij</title>
        <meta
          name="description"
          content="Heeft u vragen over onze stomerij of naaiatelier in Krimpen aan den IJssel? Bekijk hier onze veelgestelde vragen."
        />
      </Helmet>

      <Header />

      <main className="bg-background min-h-[80vh]">
        <section className="py-24 bg-black text-white border-b border-white/10">
          <div className="container mx-auto px-4 max-w-4xl text-center">
            <h1 className="font-display text-4xl md:text-5xl font-medium mb-6">
              Veelgestelde <span className="text-white/80 italic">Vragen</span>
            </h1>
            <p className="text-lg text-white/70 leading-relaxed font-light">
              Hier vindt u antwoorden op de meest gestelde vragen rondom onze dienstverlening.
            </p>
          </div>
        </section>

        <section className="py-24">
          <div className="container mx-auto px-4 max-w-4xl">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <Accordion type="single" collapsible className="w-full">
                {faqs.map((faq, index) => (
                  <FaqItem
                    key={index}
                    value={`item-${index}`}
                    question={faq.question}
                    answer={faq.answer}
                  />
                ))}
              </Accordion>
            </motion.div>
          </div>
        </section>
      </main>

      <Footer />
    </>
  );
}

export default FaqPage;
