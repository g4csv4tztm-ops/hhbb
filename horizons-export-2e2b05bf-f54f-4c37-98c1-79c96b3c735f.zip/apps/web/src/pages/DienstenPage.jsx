
import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';

function DienstenPage() {
  const servicesList = [
    {
      title: 'Kledingreparatie',
      description: 'Heeft uw favoriete kledingstuk een scheur, losse naad of ontbreekt er een knoop? Onze vakkundige coupeuses repareren uw kleding onzichtbaar en duurzaam, zodat u er weer jaren van kunt genieten.',
      image: 'https://images.unsplash.com/photo-1445960169705-e0fb7b5c7f39',
    },
    {
      title: 'Kleding Vermaken & Maatwerk',
      description: 'Een perfecte pasvorm is essentieel voor een elegante uitstraling. Wij nemen kleding in, leggen het uit of korten het in. Van pantalons tot avondjurken, wij creëren een silhouet dat u op het lijf geschreven is.',
      image: 'https://images.unsplash.com/photo-1682037173605-0f84eb310d0f',
    },
    {
      title: 'Ritsen Vervangen',
      description: 'Een kapotte rits betekent niet het einde van uw kledingstuk. Wij vervangen ritsen in broeken, jassen, vesten en zelfs tassen met hoogwaardige YKK-ritsen in de exact juiste kleur.',
      image: 'https://images.unsplash.com/photo-1445960169705-e0fb7b5c7f39',
    },
    {
      title: 'Gordijnen & Interieurtextiel',
      description: 'Ook voor uw woning bieden wij maatwerk. Wij korten gordijnen en vitrages in, herstellen naden van kussenhoezen en verzorgen ander interieurtextiel met de grootste zorg.',
      image: 'https://images.unsplash.com/photo-1682037173605-0f84eb310d0f',
    },
    {
      title: 'Professionele Stomerij',
      description: 'Voor kleding die speciale zorg nodig heeft, biedt onze stomerij de oplossing. Wij reinigen colberts, pantalons, bruidskleding en delicate stoffen zoals zijde en wol grondig maar veilig.',
      image: 'https://images.unsplash.com/photo-1682037173605-0f84eb310d0f',
    },
  ];

  return (
    <>
      <Helmet>
        <title>Onze Diensten | Crimpenhof Naaiatelier & Stomerij</title>
        <meta
          name="description"
          content="Van kledingreparatie tot professionele stomerij. Bekijk de hoogwaardige diensten van Crimpenhof Naaiatelier & Stomerij in Krimpen aan den IJssel."
        />
      </Helmet>

      <Header />

      <main className="bg-background">
        <section className="py-24 bg-black text-white">
          <div className="container mx-auto px-4 max-w-4xl text-center">
            <h1 className="font-display text-4xl md:text-5xl font-medium mb-6">
              Haute Couture <span className="text-white/80 italic">Verzorging</span>
            </h1>
            <p className="text-lg text-white/70 leading-relaxed font-light">
              Elk kledingstuk verdient een tweede leven. Ontdek wat onze ambachtelijke experts voor uw garderobe kunnen betekenen.
            </p>
          </div>
        </section>

        <section className="py-24">
          <div className="container mx-auto px-4 max-w-6xl">
            {servicesList.map((service, index) => (
              <div 
                key={index} 
                className={`flex flex-col lg:flex-row gap-12 lg:gap-20 items-center mb-24 last:mb-0 ${
                  index % 2 !== 0 ? 'lg:flex-row-reverse' : ''
                }`}
              >
                <motion.div 
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6 }}
                  className="w-full lg:w-1/2"
                >
                  <div className="aspect-[4/3] overflow-hidden bg-muted">
                    <img 
                      src={service.image} 
                      alt={service.title} 
                      className="w-full h-full object-cover transition-transform duration-700 hover:scale-105 grayscale hover:grayscale-0"
                    />
                  </div>
                </motion.div>
                
                <motion.div 
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6, delay: 0.2 }}
                  className="w-full lg:w-1/2 space-y-6"
                >
                  <h2 className="font-display text-3xl md:text-4xl">{service.title}</h2>
                  <div className="h-px w-12 bg-foreground"></div>
                  <p className="text-lg text-muted-foreground font-light leading-relaxed">
                    {service.description}
                  </p>
                  <div className="pt-4">
                    <Button asChild variant="outline" className="rounded-none border-foreground hover:bg-foreground hover:text-background uppercase tracking-widest text-xs px-8">
                      <Link to="/prijzen">Bekijk tarieven</Link>
                    </Button>
                  </div>
                </motion.div>
              </div>
            ))}
          </div>
        </section>
      </main>

      <Footer />
    </>
  );
}

export default DienstenPage;
