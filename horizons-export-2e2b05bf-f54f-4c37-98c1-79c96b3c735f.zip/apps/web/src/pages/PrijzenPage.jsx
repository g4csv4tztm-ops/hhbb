
import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import PricingRow from '@/components/PricingRow.jsx';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';

function PrijzenPage() {
  const pricingData = {
    stomerijBoven: [
      { service: 'Colbert', price: '€13,00' },
      { service: 'Blouse', price: '€10,00' },
      { service: 'Vest', price: '€20,00' },
      { service: 'Jurk', price: '€20,00' },
      { service: 'Winterjas', price: '€25,00' },
      { service: 'Gilet', price: '€12,00' },
    ],
    stomerijOnder: [
      { service: 'Pantalon', price: '€12,00' },
      { service: 'Rok', price: '€12,00' },
    ],
    stomerijSpeciaal: [
      { service: 'Compleet pak', price: '€24,00' },
      { service: 'Stropdas', price: '€10,00' },
      { service: 'Trouwjurk simpel', price: '€90,00' },
      { service: 'Trouwjurk glitters', price: '€120,00' },
      { service: 'Trouwjurk veel lagen', price: '€120,00 +/-' },
    ],
    stomerijLeer: [
      { service: 'Broek leer', price: '€40,00' },
      { service: 'Jas leer', price: '€55,00' },
    ],
    stomerijOverig: [
      { service: 'Dekbed 1 persoon', price: '€25,00' },
      { service: 'Dekbed 2 personen', price: '€30,00' },
      { service: 'Sprei 1 persoon', price: '€25,00' },
      { service: 'Sprei 2 personen', price: '€30,00' },
      { service: 'Dons 1 persoon', price: '€35,00' },
      { service: 'Dons 2 personen', price: '€40,00' },
      { service: 'Gordijnen (per m2)', price: '€7,00' },
      { service: 'Gordijnen met voering (per m2)', price: '€9,00' },
    ],
    vermakenBroek: [
      { service: 'Broek inkorten normaal', price: '€13,00' },
      { service: 'Broek inkorten origineel', price: '€16,00' },
      { service: 'Heren pantalon inkorten', price: '€20,00' },
      { service: 'Broek afslanken', price: '€20,00' },
      { service: 'Broek band innemen', price: '€25,00' },
      { service: 'Broek band wijder', price: '€18,00' },
      { service: 'Nieuwe rits', price: '€12,00' },
      { service: 'Nieuwe broekzak', price: '€20,00 - €22,00' },
      { service: 'Elastiek in broek/jas', price: '€20,00' },
    ],
    vermakenBoven: [
      { service: 'Lengte korter (Overhemd/Blouse)', price: '€15,00' },
      { service: 'Mouwen korter', price: '€18,00' },
      { service: 'Mouwen korter met knopen', price: '€20,00' },
      { service: 'Innemen', price: '€8,00' },
      { service: 'Blouse of Jurk dicht stikken', price: '€15,00' },
    ],
    vermakenJurk: [
      { service: 'Inkorten', price: '€20,00' },
      { service: 'Inkorten groot/met voering', price: '€25,00' },
      { service: 'Nieuwe rits in', price: '€20,00' },
    ],
    vermakenColbert: [
      { service: 'Innemen', price: '€30,00' },
      { service: 'Lengte korter', price: '€35,00' },
      { service: 'Mouwen korter', price: '€25,00' },
      { service: 'Mouwen korter met knopen', price: '€35,00' },
    ],
    vermakenOverig: [
      { service: 'Nieuwe zak voor jas', price: '€15,00' },
      { service: 'Elleboog patches vast stikken', price: '€11,00' },
      { service: 'Judo band stikken', price: '€10,00' },
      { service: 'Jas nieuwe rits', price: '€40,00' },
      { service: 'Jas rits waterdicht', price: '€40,00 - €50,00' },
      { service: 'Dons jas rits', price: '€40,00' },
      { service: 'Suede/leren jas reparatie', price: '€40,00 - €45,00' },
    ],
  };

  return (
    <>
      <Helmet>
        <title>Tarieven | Crimpenhof Naaiatelier & Stomerij</title>
        <meta
          name="description"
          content="Transparante prijzen voor al onze stomerij en kledingreparatie diensten in Krimpen aan den IJssel."
        />
      </Helmet>

      <Header />

      <main className="bg-background">
        <section className="py-24 border-b border-border bg-secondary/30">
          <div className="container mx-auto px-4 max-w-4xl text-center">
            <h1 className="font-display text-4xl md:text-5xl font-medium mb-6">
              Transparante <span className="text-foreground italic">Tarieven</span>
            </h1>
            <p className="text-lg text-muted-foreground leading-relaxed">
              Kwaliteit mag een eerlijke prijs hebben. Ontdek onze uitgebreide prijslijst voor reparaties en stomerij.
            </p>
          </div>
        </section>

        <section className="py-24">
          <div className="container mx-auto px-4 max-w-7xl">
            
            <div className="mb-12 p-6 bg-black text-white border-l-4 border-foreground text-sm md:text-base font-light tracking-wide space-y-2">
              <p>• Strijken per kledingstuk is tussen de €4,00 en €5,00</p>
              <p>• Prijzen kunnen variëren afhankelijk van het specifieke kledingstuk en het vereiste werk.</p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
              {/* STOMERIJ SECTIE */}
              <div className="space-y-12">
                <h2 className="font-display text-3xl border-b border-foreground pb-4 inline-block">Stomerij</h2>
                
                <Card className="rounded-none border-border shadow-none">
                  <CardHeader className="bg-secondary/30 pb-4">
                    <CardTitle className="font-display text-xl">Bovenkleding</CardTitle>
                  </CardHeader>
                  <CardContent className="pt-6">
                    {pricingData.stomerijBoven.map((item, i) => (
                      <PricingRow key={i} {...item} />
                    ))}
                  </CardContent>
                </Card>

                <Card className="rounded-none border-border shadow-none">
                  <CardHeader className="bg-secondary/30 pb-4">
                    <CardTitle className="font-display text-xl">Onderkleding</CardTitle>
                  </CardHeader>
                  <CardContent className="pt-6">
                    {pricingData.stomerijOnder.map((item, i) => (
                      <PricingRow key={i} {...item} />
                    ))}
                  </CardContent>
                </Card>

                <Card className="rounded-none border-border shadow-none">
                  <CardHeader className="bg-secondary/30 pb-4">
                    <CardTitle className="font-display text-xl">Speciaal Stomen</CardTitle>
                  </CardHeader>
                  <CardContent className="pt-6">
                    {pricingData.stomerijSpeciaal.map((item, i) => (
                      <PricingRow key={i} {...item} />
                    ))}
                  </CardContent>
                </Card>

                <Card className="rounded-none border-border shadow-none">
                  <CardHeader className="bg-secondary/30 pb-4">
                    <CardTitle className="font-display text-xl">Leer Stomen</CardTitle>
                  </CardHeader>
                  <CardContent className="pt-6">
                    {pricingData.stomerijLeer.map((item, i) => (
                      <PricingRow key={i} {...item} />
                    ))}
                  </CardContent>
                </Card>

                <Card className="rounded-none border-border shadow-none">
                  <CardHeader className="bg-secondary/30 pb-4">
                    <CardTitle className="font-display text-xl">Interieur & Overig</CardTitle>
                  </CardHeader>
                  <CardContent className="pt-6">
                    {pricingData.stomerijOverig.map((item, i) => (
                      <PricingRow key={i} {...item} />
                    ))}
                  </CardContent>
                </Card>
              </div>

              {/* VERMAKEN SECTIE */}
              <div className="space-y-12">
                <h2 className="font-display text-3xl border-b border-foreground pb-4 inline-block">Kleding Vermaken</h2>
                
                <Card className="rounded-none border-border shadow-none">
                  <CardHeader className="bg-secondary/30 pb-4">
                    <CardTitle className="font-display text-xl">Broeken</CardTitle>
                  </CardHeader>
                  <CardContent className="pt-6">
                    {pricingData.vermakenBroek.map((item, i) => (
                      <PricingRow key={i} {...item} />
                    ))}
                  </CardContent>
                </Card>

                <Card className="rounded-none border-border shadow-none">
                  <CardHeader className="bg-secondary/30 pb-4">
                    <CardTitle className="font-display text-xl">Overhemd / Blouse / Vest</CardTitle>
                  </CardHeader>
                  <CardContent className="pt-6">
                    {pricingData.vermakenBoven.map((item, i) => (
                      <PricingRow key={i} {...item} />
                    ))}
                  </CardContent>
                </Card>

                <Card className="rounded-none border-border shadow-none">
                  <CardHeader className="bg-secondary/30 pb-4">
                    <CardTitle className="font-display text-xl">Jurk & Rok</CardTitle>
                  </CardHeader>
                  <CardContent className="pt-6">
                    {pricingData.vermakenJurk.map((item, i) => (
                      <PricingRow key={i} {...item} />
                    ))}
                  </CardContent>
                </Card>

                <Card className="rounded-none border-border shadow-none">
                  <CardHeader className="bg-secondary/30 pb-4">
                    <CardTitle className="font-display text-xl">Colbert</CardTitle>
                  </CardHeader>
                  <CardContent className="pt-6">
                    {pricingData.vermakenColbert.map((item, i) => (
                      <PricingRow key={i} {...item} />
                    ))}
                  </CardContent>
                </Card>

                <Card className="rounded-none border-border shadow-none">
                  <CardHeader className="bg-secondary/30 pb-4">
                    <CardTitle className="font-display text-xl">Overige Reparaties</CardTitle>
                  </CardHeader>
                  <CardContent className="pt-6">
                    {pricingData.vermakenOverig.map((item, i) => (
                      <PricingRow key={i} {...item} />
                    ))}
                  </CardContent>
                </Card>
              </div>
            </div>

            <div className="mt-20 text-center">
              <p className="text-muted-foreground mb-6 font-light">
                Staat uw kledingstuk of wens er niet bij? Wij leveren maatwerk.
              </p>
              <Button asChild size="lg" className="bg-black text-white hover:bg-black/80 rounded-none uppercase tracking-widest px-10">
                <Link to="/contact">Neem contact op voor een prijsindicatie</Link>
              </Button>
            </div>

          </div>
        </section>
      </main>

      <Footer />
    </>
  );
}

export default PrijzenPage;
