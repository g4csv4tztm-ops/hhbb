
import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';

function OverOnsPage() {
  return (
    <>
      <Helmet>
        <title>Over Ons | Crimpenhof Naaiatelier & Stomerij</title>
        <meta
          name="description"
          content="Ontdek het verhaal achter Crimpenhof Naaiatelier & Stomerij. Ervaring, vakmanschap en klantvriendelijkheid staan bij ons centraal."
        />
      </Helmet>

      <Header />

      <main className="bg-background">
        <section className="py-24 border-b border-border">
          <div className="container mx-auto px-4 max-w-4xl text-center">
            <motion.h1 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="font-display text-4xl md:text-6xl font-medium mb-6"
            >
              Onze Passie voor <span className="text-muted-foreground italic">Textiel</span>
            </motion.h1>
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="text-lg md:text-xl text-muted-foreground leading-relaxed"
            >
              Jarenlange ervaring gecombineerd met traditioneel vakmanschap. 
              Wij brengen kleding terug naar de perfecte staat.
            </motion.p>
          </div>
        </section>

        <section className="py-24">
          <div className="container mx-auto px-4 max-w-7xl">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
              <motion.div
                initial={{ opacity: 0, x: -30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
              >
                <div className="relative">
                  <div className="absolute -inset-4 border border-foreground/20 -z-10 translate-x-4 translate-y-4"></div>
                  <img
                    src="https://images.unsplash.com/photo-1445960169705-e0fb7b5c7f39"
                    alt="Kleermaker gereedschap"
                    className="w-full h-[600px] object-cover grayscale hover:grayscale-0 transition-all duration-700"
                  />
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: 30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
                className="space-y-8"
              >
                <h2 className="font-display text-3xl md:text-4xl">Een rijke traditie in Krimpen aan den IJssel</h2>
                <div className="h-px w-16 bg-foreground"></div>
                <div className="space-y-6 text-muted-foreground leading-relaxed text-lg font-light">
                  <p>
                    Crimpenhof Naaiatelier & Stomerij is ontstaan uit een diepgewortelde liefde voor hoogwaardige kleding en textiel. Al vele jaren bedienen wij de inwoners en bedrijven in Krimpen aan den IJssel en omstreken met een ongeëvenaarde toewijding.
                  </p>
                  <p>
                    Of het nu gaat om het perfect op maat maken van een kostuum, het zorgvuldig reinigen van delicate zijde, of het repareren van uw favoriete winterjas; wij benaderen elk kledingstuk met hetzelfde respect en precisie.
                  </p>
                  <p>
                    Onze werkwijze kenmerkt zich door betrouwbaarheid, vakmanschap en klantvriendelijkheid. Wij verwelkomen zowel particulieren als zakelijke klanten en streven er altijd naar om uw verwachtingen te overtreffen.
                  </p>
                </div>
                
                <div className="grid grid-cols-2 gap-8 pt-8 border-t border-border">
                  <div>
                    <h3 className="font-display text-2xl text-foreground mb-2">10+</h3>
                    <p className="text-sm uppercase tracking-wider text-muted-foreground">Jaren Ervaring</p>
                  </div>
                  <div>
                    <h3 className="font-display text-2xl text-foreground mb-2">100%</h3>
                    <p className="text-sm uppercase tracking-wider text-muted-foreground">Kwaliteitsgarantie</p>
                  </div>
                </div>
              </motion.div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </>
  );
}

export default OverOnsPage;
