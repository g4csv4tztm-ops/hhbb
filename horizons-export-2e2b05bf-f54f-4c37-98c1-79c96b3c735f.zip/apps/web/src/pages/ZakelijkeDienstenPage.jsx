import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Building2, Hotel, ShoppingBag, Truck } from 'lucide-react';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';

function ZakelijkeDienstenPage() {
  const industries = [
    { icon: Hotel, title: 'Hotels & Horeca', desc: 'Reiniging van tafellinnen, beddengoed en bedrijfskleding van personeel.' },
    { icon: ShoppingBag, title: 'Kledingwinkels', desc: 'Vermaak- en herstelservice voor uw klanten, direct uitbesteed aan ons atelier.' },
    { icon: Building2, title: 'Bedrijven', desc: 'Representatieve bedrijfskleding, veilig gereinigd en indien nodig professioneel hersteld.' },
    { icon: Truck, title: 'Haal- en Brengservice', desc: 'Voor vaste zakelijke partners bieden we logistieke oplossingen op maat.' }
  ];

  return (
    <>
      <Helmet>
        <title>Zakelijke Diensten | Crimpenhof Naaiatelier & Stomerij</title>
        <meta
          name="description"
          content="Betrouwbare textielverzorging voor de zakelijke markt. Voor hotels, horeca, kledingwinkels en bedrijven in Krimpen aan den IJssel."
        />
      </Helmet>

      <Header />

      <main className="bg-background">
        <section className="relative py-32 bg-black text-white flex items-center">
          <div className="absolute inset-0 z-0 opacity-30">
            <img 
              src="https://images.unsplash.com/photo-1682037173605-0f84eb310d0f" 
              alt="Zakelijke stomerij" 
              className="w-full h-full object-cover grayscale"
            />
          </div>
          <div className="container mx-auto px-4 relative z-10 max-w-5xl text-center">
            <motion.h1 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="font-display text-4xl md:text-6xl font-medium mb-6 text-balance"
            >
              Zakelijke <span className="text-white/80 italic">Partnerschappen</span>
            </motion.h1>
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="text-lg md:text-xl text-white/80 leading-relaxed max-w-2xl mx-auto font-light"
            >
              Uw textiel is het visitekaartje van uw onderneming. Wij zorgen ervoor dat uw bedrijfskleding en linnengoed altijd in onberispelijke staat is.
            </motion.p>
          </div>
        </section>

        <section className="py-24">
          <div className="container mx-auto px-4 max-w-7xl">
            <div className="text-center mb-16">
              <h2 className="font-display text-3xl md:text-4xl mb-4">Onze Focus Sectoren</h2>
              <div className="h-1 w-16 bg-foreground mx-auto"></div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              {industries.map((ind, i) => (
                <div key={i} className="p-8 border border-border bg-secondary/20 hover:bg-secondary/50 transition-colors duration-300">
                  <ind.icon className="w-10 h-10 text-foreground mb-6 stroke-1" />
                  <h3 className="font-display text-xl mb-3">{ind.title}</h3>
                  <p className="text-muted-foreground text-sm leading-relaxed">{ind.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="py-24 bg-black text-white">
          <div className="container mx-auto px-4 max-w-4xl text-center">
            <h2 className="font-display text-3xl md:text-4xl mb-6">Maatwerk voor uw Onderneming</h2>
            <p className="text-lg text-white/70 font-light leading-relaxed mb-10">
              Wij begrijpen dat zakelijke klanten behoefte hebben aan snelheid, consistentie en kwaliteit. Neem contact op om de mogelijkheden voor een langdurig partnerschap te bespreken.
            </p>
            <Button asChild size="lg" className="bg-white text-black hover:bg-white/90 rounded-none uppercase tracking-widest text-sm px-10 py-6">
              <Link to="/contact">Vraag een zakelijke offerte aan</Link>
            </Button>
          </div>
        </section>
      </main>

      <Footer />
    </>
  );
}

export default ZakelijkeDienstenPage;