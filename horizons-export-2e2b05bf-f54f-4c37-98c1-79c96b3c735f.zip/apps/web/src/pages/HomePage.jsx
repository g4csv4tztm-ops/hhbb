
import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Scissors, Sparkles, Building, Shirt } from 'lucide-react';
import { Button } from '@/components/ui/button';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import ServiceCard from '@/components/ServiceCard.jsx';
import TestimonialCard from '@/components/TestimonialCard.jsx';

function HomePage() {
  const services = [
    {
      icon: Scissors,
      title: 'Kledingherstellingen',
      description: 'Verleng de levensduur van uw favoriete kleding met onze vakkundige herstelservice.',
    },
    {
      icon: Sparkles,
      title: 'Stomerij',
      description: 'Professionele, diepe reiniging voor delicate stoffen, pakken en bruidskleding.',
    },
    {
      icon: Shirt,
      title: 'Maatwerk & Vermaken',
      description: 'Perfect passend gemaakt. Wij passen uw kleding aan naar uw unieke lichaamsmaten.',
    },
    {
      icon: Building,
      title: 'Zakelijke Dienstverlening',
      description: 'Betrouwbare textielverzorging en bedrijfskleding onderhoud voor uw onderneming.',
    },
  ];

  const testimonials = [
    {
      name: 'E. de Vries',
      review: 'Mijn trouwpak perfect op maat laten maken. Zeer vakkundig en met oog voor het kleinste detail.',
      rating: 5,
    },
    {
      name: 'M. Jansen',
      review: 'Uitstekende stomerij! Mijn zijden jurk ziet er weer uit als nieuw. Luxe service voor een eerlijke prijs.',
      rating: 5,
    },
    {
      name: 'J. Bakker',
      review: 'Als hotel maken we veel gebruik van hun zakelijke diensten. Altijd stipt, betrouwbaar en professioneel.',
      rating: 5,
    },
  ];

  return (
    <>
      <Helmet>
        <title>Crimpenhof Naaiatelier & Stomerij | Luxe Kledingverzorging</title>
        <meta
          name="description"
          content="Crimpenhof Naaiatelier & Stomerij – Vakmanschap en zorg voor uw kleding. Luxe kledingherstel en professionele stomerij in Krimpen aan den IJssel."
        />
      </Helmet>

      <Header />

      <main>
        {/* Hero Section */}
        <section className="relative min-h-[90dvh] flex items-center justify-center bg-black">
          <div className="absolute inset-0 z-0">
            <img 
              src="https://images.unsplash.com/photo-1445960169705-e0fb7b5c7f39" 
              alt="Professionele kleermaker gereedschap" 
              className="w-full h-full object-cover opacity-40 mix-blend-luminosity grayscale"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent"></div>
          </div>

          <div className="container mx-auto px-4 relative z-10 text-center max-w-5xl">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, ease: "easeOut" }}
            >
              <h1 className="font-display text-4xl md:text-6xl lg:text-7xl font-medium text-white mb-6 leading-tight text-balance">
                Crimpenhof <br/>
                <span className="text-white/80 italic">Naaiatelier & Stomerij</span>
              </h1>
              <p className="text-lg md:text-2xl text-white/80 font-light mb-10 max-w-2xl mx-auto tracking-wide">
                Vakmanschap en uiterste zorg voor uw kleding.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-6 justify-center items-center">
                <Button asChild size="lg" className="bg-white text-black hover:bg-white/90 rounded-none px-8 py-6 text-sm tracking-widest uppercase w-full sm:w-auto">
                  <Link to="/contact">Neem contact op</Link>
                </Button>
                <Button asChild size="lg" variant="outline" className="bg-transparent border-white text-white hover:bg-white hover:text-black rounded-none px-8 py-6 text-sm tracking-widest uppercase w-full sm:w-auto transition-colors duration-300">
                  <Link to="/zakelijke-diensten">Zakelijke diensten</Link>
                </Button>
              </div>
            </motion.div>
          </div>
        </section>

        {/* Services Bento Grid */}
        <section className="py-24 bg-background">
          <div className="container mx-auto px-4 max-w-7xl">
            <div className="text-center mb-16">
              <h2 className="font-display text-3xl md:text-5xl mb-4">Onze Expertise</h2>
              <div className="h-1 w-20 bg-foreground mx-auto mb-6"></div>
              <p className="text-muted-foreground max-w-2xl mx-auto">
                Ontdek onze uitgebreide diensten, uitgevoerd met precisie en hoogwaardige materialen.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2">
                <ServiceCard 
                  icon={services[0].icon}
                  title={services[0].title}
                  description={services[0].description}
                  className="h-full bg-secondary/30"
                />
              </div>
              <div className="lg:col-span-1">
                <ServiceCard 
                  icon={services[1].icon}
                  title={services[1].title}
                  description={services[1].description}
                  className="h-full"
                />
              </div>
              <div className="lg:col-span-1">
                <ServiceCard 
                  icon={services[2].icon}
                  title={services[2].title}
                  description={services[2].description}
                  className="h-full"
                />
              </div>
              <div className="lg:col-span-2">
                <ServiceCard 
                  icon={services[3].icon}
                  title={services[3].title}
                  description={services[3].description}
                  className="h-full bg-black text-white [&_h3]:text-white [&_p]:text-white/70"
                />
              </div>
            </div>
          </div>
        </section>

        {/* Testimonials */}
        <section className="py-24 bg-secondary">
          <div className="container mx-auto px-4 max-w-7xl">
            <div className="text-center mb-16">
              <h2 className="font-display text-3xl md:text-5xl mb-4">Cliënt Ervaringen</h2>
              <div className="h-1 w-20 bg-foreground mx-auto"></div>
            </div>

            <div className="columns-1 md:columns-2 lg:columns-3 gap-6">
              {testimonials.map((testimonial, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                >
                  <TestimonialCard {...testimonial} />
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Location / Map */}
        <section className="py-0">
          <div className="grid grid-cols-1 lg:grid-cols-2">
            <div className="bg-black text-white p-12 lg:p-24 flex flex-col justify-center">
              <h2 className="font-display text-3xl md:text-4xl mb-6 text-white">Bezoek Onze Boutique</h2>
              <p className="text-white/80 mb-8 leading-relaxed font-light text-lg">
                U bent van harte welkom in ons atelier voor persoonlijk advies, het inmeten van kleding of het afgeven van uw stomerij. 
              </p>
              <address className="not-italic space-y-2 mb-8 text-white/90">
                <p className="text-xl">Raad Huisplein 80B</p>
                <p className="text-xl">2922 AD Krimpen aan den IJssel</p>
                <p className="text-xl text-white/70 pt-4">T: 0180 554 425</p>
              </address>
              <Button asChild variant="outline" className="w-fit border-white text-white hover:bg-white hover:text-black rounded-none">
                <Link to="/contact">Route plannen</Link>
              </Button>
            </div>
            <div className="h-[400px] lg:h-auto w-full">
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2460.627757913318!2d4.591040315802264!3d51.92244297970597!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47c433a0c5c3c0a5%3A0x6b772c9a9b8f2d!2sRaadhuisplein%2080B%2C%202922%20AD%20Krimpen%20aan%20den%20IJssel!5e0!3m2!1snl!2snl!4v1680000000000!5m2!1snl!2snl"
                width="100%"
                height="100%"
                style={{ border: 0, filter: 'grayscale(100%) contrast(1.2)' }}
                allowFullScreen=""
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                title="Locatie Crimpenhof Naaiatelier & Stomerij"
              ></iframe>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </>
  );
}

export default HomePage;
